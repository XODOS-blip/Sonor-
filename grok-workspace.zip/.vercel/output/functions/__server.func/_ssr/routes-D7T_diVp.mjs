import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { o as toolBySlug } from "./catalog-B9U2SfMu.mjs";
import { n as SiteShell, t as PageBody } from "./shell-Fovg4XgI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D7T_diVp.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const tool = toolBySlug("suno");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, {
		current: "suno",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageBody, { tool })
	});
}
//#endregion
export { Home as component };
