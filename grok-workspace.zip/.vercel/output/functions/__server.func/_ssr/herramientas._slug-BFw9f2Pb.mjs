import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as Route } from "./router-o0wD-qf7.mjs";
import { n as SiteShell, t as PageBody } from "./shell-Fovg4XgI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/herramientas._slug-BFw9f2Pb.js
var import_jsx_runtime = require_jsx_runtime();
function ToolPage() {
	const { tool } = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, {
		current: tool.slug,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageBody, { tool })
	});
}
//#endregion
export { ToolPage as component };
