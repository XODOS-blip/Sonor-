import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { o as toolBySlug } from "./catalog-B9U2SfMu.mjs";
import { n as SiteShell, t as PageBody } from "./shell-Fovg4XgI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/video-BZcvJndc.js
var import_jsx_runtime = require_jsx_runtime();
function VideoPage() {
	const tool = toolBySlug("suno-video");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, {
		current: "suno-video",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageBody, {
			tool,
			defaultFormat: "mp4"
		})
	});
}
//#endregion
export { VideoPage as component };
