//#region node_modules/.nitro/vite/services/ssr/assets/parse-CWczB3dl.js
var UUID_RE = new RegExp(`^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$`, "i");
function parseSunoInput(raw) {
	const trimmed = raw.trim();
	if (!trimmed) return null;
	if (UUID_RE.test(trimmed)) return {
		kind: "uuid",
		id: trimmed.toLowerCase()
	};
	let url;
	try {
		url = new URL(trimmed.includes("://") ? trimmed : `https://${trimmed}`);
	} catch {
		return null;
	}
	const host = url.hostname.replace(/^www\./, "").toLowerCase();
	if (host === "suno.com" || host === "suno.ai") {
		const parts = url.pathname.split("/").filter(Boolean);
		if (parts[0] === "song" && parts[1] && UUID_RE.test(parts[1])) return {
			kind: "song",
			id: parts[1].toLowerCase()
		};
		if (parts[0] === "playlist" && parts[1] && UUID_RE.test(parts[1])) return {
			kind: "playlist",
			id: parts[1].toLowerCase()
		};
		if (parts[0] === "s" && parts[1]) return {
			kind: "short",
			id: parts[1]
		};
		if (parts[0] === "embed" && parts[1] && UUID_RE.test(parts[1])) return {
			kind: "song",
			id: parts[1].toLowerCase()
		};
	}
	if (host.includes("suno") || host.includes("mureka") || host.includes("soundraw") || host.includes("mubert") || host.includes("loudly") || host.includes("openmusic") || host.includes("makebestmusic") || host.includes("aisongmaker") || host.includes("udio")) return {
		kind: "generic",
		url: url.toString()
	};
	return {
		kind: "generic",
		url: url.toString()
	};
}
//#endregion
export { parseSunoInput as t };
