import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { i as string, r as object } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/functions-CnQnpW31.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var Input = object({ url: string().min(8).max(2e3) });
var resolveTrack_createServerFn_handler = createServerRpc({
	id: "bc2ca3efe8067b697acb0dfb81ce8c8464485abd0168c4c39bf5d07140218137",
	name: "resolveTrack",
	filename: "src/lib/suno/functions.ts"
}, (opts) => resolveTrack.__executeServer(opts));
var resolveTrack = createServerFn({ method: "POST" }).validator((data) => Input.parse(data)).handler(resolveTrack_createServerFn_handler, async ({ data }) => {
	const { resolveSunoUrl } = await import("./resolve.server-cZQNDZ2B.mjs");
	return resolveSunoUrl(data.url);
});
//#endregion
export { resolveTrack_createServerFn_handler };
