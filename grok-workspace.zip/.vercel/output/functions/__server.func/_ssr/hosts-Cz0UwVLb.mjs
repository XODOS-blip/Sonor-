//#region node_modules/.nitro/vite/services/ssr/assets/hosts-Cz0UwVLb.js
var SUFFIXES = ["suno.ai", "suno.com"];
var EXACT = /* @__PURE__ */ new Set([
	"cdn1.suno.ai",
	"cdn2.suno.ai",
	"cdn.suno.ai",
	"d2lwuy8qc234o3.cloudfront.net",
	"studio-api-prod.suno.com",
	"studio-api.prod.suno.com"
]);
function isPrivateHostname(hostname) {
	const host = hostname.replace(/^\[|\]$/g, "").toLowerCase();
	if (host === "localhost" || host.endsWith(".local") || host.endsWith(".internal")) return true;
	if (/^(127\.|10\.|0\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[0-1])\.)/.test(host)) return true;
	if (host === "::1" || host.startsWith("fe80:") || host.startsWith("fc") || host.startsWith("fd")) return true;
	return false;
}
function isAllowedMediaUrl(raw) {
	try {
		const u = new URL(raw);
		if (u.protocol !== "https:") return false;
		const host = u.hostname.toLowerCase();
		if (isPrivateHostname(host)) return false;
		if (EXACT.has(host)) return true;
		return SUFFIXES.some((s) => host === s || host.endsWith(`.${s}`));
	} catch {
		return false;
	}
}
var PAGE_HOSTS = /* @__PURE__ */ new Set([
	"suno.com",
	"www.suno.com",
	"suno.ai",
	"www.suno.ai"
]);
//#endregion
export { isAllowedMediaUrl as n, PAGE_HOSTS as t };
