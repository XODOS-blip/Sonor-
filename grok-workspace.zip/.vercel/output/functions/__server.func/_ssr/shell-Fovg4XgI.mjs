import { i as __toESM } from "../_runtime.mjs";
import { a as Trigger2, c as require_jsx_runtime, i as Root2, l as require_react, n as Header, o as Slot, r as Item, t as Content2 } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { i as string, r as object } from "../_libs/zod.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { a as sanitizeFilename, i as formatDuration, n as cn, r as formatCount, t as NAV_TOOLS } from "./catalog-B9U2SfMu.mjs";
import { a as Play, c as Menu, d as Download, f as ClipboardPaste, i as Share2, l as LoaderCircle, m as Check, o as Pause, p as ChevronDown, r as Sparkles, s as Music2, t as X, u as Link2 } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import "./parse-CWczB3dl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-Fovg4XgI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Accordion = Root2;
var AccordionItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
	ref,
	className: cn("border-b border-border", className),
	...props
}));
AccordionItem.displayName = "AccordionItem";
var AccordionTrigger = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
	className: "flex",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Trigger2, {
		ref,
		className: cn("flex flex-1 items-center justify-between gap-4 py-5 text-left text-[15px] font-medium transition-colors hover:text-accent [&[data-state=open]>svg]:rotate-180", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4 shrink-0 text-muted-foreground transition-transform duration-200" })]
	})
}));
AccordionTrigger.displayName = "AccordionTrigger";
var AccordionContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: "overflow-hidden text-sm text-muted-foreground data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down",
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("pb-5 leading-relaxed", className),
		children
	})
}));
AccordionContent.displayName = "AccordionContent";
function floatTo16(input) {
	const out = new Int16Array(input.length);
	for (let i = 0; i < input.length; i++) {
		const s = Math.max(-1, Math.min(1, input[i] ?? 0));
		out[i] = s < 0 ? Math.round(s * 32768) : Math.round(s * 32767);
	}
	return out;
}
function interleave(buffer) {
	const ch = buffer.numberOfChannels;
	const len = buffer.length;
	if (ch === 1) return floatTo16(buffer.getChannelData(0));
	const left = buffer.getChannelData(0);
	const right = buffer.getChannelData(1);
	const out = new Int16Array(len * 2);
	for (let i = 0; i < len; i++) {
		const l = Math.max(-1, Math.min(1, left[i] ?? 0));
		const r = Math.max(-1, Math.min(1, right[i] ?? 0));
		out[i * 2] = l < 0 ? Math.round(l * 32768) : Math.round(l * 32767);
		out[i * 2 + 1] = r < 0 ? Math.round(r * 32768) : Math.round(r * 32767);
	}
	return out;
}
function encodeWav(buffer) {
	const channels = Math.min(2, buffer.numberOfChannels);
	const samples = interleave(buffer);
	const bytesPerSample = 2;
	const blockAlign = channels * bytesPerSample;
	const dataSize = samples.length * bytesPerSample;
	const header = 44;
	const ab = new ArrayBuffer(header + dataSize);
	const view = new DataView(ab);
	const writeStr = (offset, s) => {
		for (let i = 0; i < s.length; i++) view.setUint8(offset + i, s.charCodeAt(i));
	};
	writeStr(0, "RIFF");
	view.setUint32(4, 36 + dataSize, true);
	writeStr(8, "WAVE");
	writeStr(12, "fmt ");
	view.setUint32(16, 16, true);
	view.setUint16(20, 1, true);
	view.setUint16(22, channels, true);
	view.setUint32(24, buffer.sampleRate, true);
	view.setUint32(28, buffer.sampleRate * blockAlign, true);
	view.setUint16(32, blockAlign, true);
	view.setUint16(34, 16, true);
	writeStr(36, "data");
	view.setUint32(40, dataSize, true);
	new Int16Array(ab, header).set(samples);
	return new Blob([ab], { type: "audio/wav" });
}
async function decodeAudio(data) {
	const ctx = new AudioContext();
	try {
		const copy = data.slice(0);
		return await ctx.decodeAudioData(copy);
	} finally {
		await ctx.close().catch(() => void 0);
	}
}
function triggerDownload(blob, filename) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.rel = "noopener";
	document.body.appendChild(a);
	a.click();
	a.remove();
	setTimeout(() => URL.revokeObjectURL(url), 4e3);
}
function mediaProxyUrl(src, filename, download = false) {
	const params = new URLSearchParams({ url: src });
	if (filename) params.set("filename", filename);
	if (download) params.set("dl", "1");
	return `/api/media?${params.toString()}`;
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var Input$1 = object({ url: string().min(8).max(2e3) });
var resolveTrack = createServerFn({ method: "POST" }).validator((data) => Input$1.parse(data)).handler(createSsrRpc("bc2ca3efe8067b697acb0dfb81ce8c8464485abd0168c4c39bf5d07140218137"));
var KEY = "sunodescarga.history.v1";
var MAX = 24;
function read() {
	if (typeof window === "undefined") return [];
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed : [];
	} catch {
		return [];
	}
}
function pushHistory(track) {
	const list = [{
		id: track.id,
		title: track.title,
		artist: track.artist,
		imageUrl: track.media.imageUrl,
		pageUrl: track.pageUrl,
		savedAt: Date.now()
	}, ...read().filter((item) => item.id !== track.id)].slice(0, MAX);
	localStorage.setItem(KEY, JSON.stringify(list));
	return list;
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,box-shadow] duration-150 ease-[var(--ease-smooth-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:opacity-90",
			secondary: "bg-secondary text-secondary-foreground shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			outline: "bg-transparent text-foreground shadow-[var(--shadow-border)] hover:bg-secondary",
			ghost: "bg-transparent text-foreground hover:bg-secondary",
			accent: "bg-accent text-accent-foreground hover:opacity-90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 rounded-sm px-3 text-[13px]",
			lg: "h-12 rounded-lg px-5 text-[15px]",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-medium tracking-wide uppercase", {
	variants: { variant: {
		default: "bg-secondary text-muted-foreground",
		accent: "bg-accent/15 text-accent",
		solid: "bg-primary text-primary-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
	type,
	className: cn("flex h-12 w-full rounded-md bg-secondary px-4 text-[15px] text-foreground shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 disabled:cursor-not-allowed disabled:opacity-50", className),
	ref,
	...props
}));
Input.displayName = "Input";
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-secondary", className),
		...props
	});
}
var FORMATS = [
	{
		id: "mp3",
		label: "MP3 / M4A",
		hint: "Audio original"
	},
	{
		id: "wav",
		label: "WAV",
		hint: "Sin pérdidas"
	},
	{
		id: "mp4",
		label: "MP4",
		hint: "Vídeo + audio"
	}
];
function Cover({ src, title, className }) {
	const url = src ? mediaProxyUrl(src) : null;
	if (!url) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex items-center justify-center bg-secondary text-muted-foreground", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music2, { className: "size-8" })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: url,
		alt: `Portada de ${title}`,
		className: cn("object-cover", className),
		crossOrigin: "anonymous"
	});
}
function AudioPlayer({ track }) {
	const audioRef = (0, import_react.useRef)(null);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [progress, setProgress] = (0, import_react.useState)(0);
	const src = track.media.audioUrl ? mediaProxyUrl(track.media.audioUrl) : track.media.videoUrl ? mediaProxyUrl(track.media.videoUrl) : null;
	(0, import_react.useEffect)(() => {
		setPlaying(false);
		setProgress(0);
	}, [track.id]);
	if (!src) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
				ref: audioRef,
				src,
				preload: "metadata",
				onTimeUpdate: (e) => {
					const el = e.currentTarget;
					setProgress(el.duration ? el.currentTime / el.duration : 0);
				},
				onEnded: () => setPlaying(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				size: "icon",
				variant: "secondary",
				className: "size-11 shrink-0 rounded-full",
				"aria-label": playing ? "Pausar" : "Reproducir",
				onClick: () => {
					const el = audioRef.current;
					if (!el) return;
					if (el.paused) {
						el.play();
						setPlaying(true);
					} else {
						el.pause();
						setPlaying(false);
					}
				},
				children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "ml-0.5 size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-1 flex-1 overflow-hidden rounded-full bg-secondary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full bg-accent transition-[width] duration-150",
					style: { width: `${Math.round(progress * 100)}%` }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-10 text-right font-mono text-xs tabular-nums text-muted-foreground",
				children: formatDuration(track.duration)
			})
		]
	});
}
async function downloadTrack(track, format, onProgress) {
	const base = sanitizeFilename(`${track.artist} - ${track.title}`);
	if (format === "mp4") {
		const src = track.media.videoUrl;
		if (!src) throw new Error("Esta pista no tiene vídeo MP4 público.");
		onProgress("Descargando vídeo…");
		const res = await fetch(mediaProxyUrl(src, `${base}.mp4`, true));
		if (!res.ok) throw new Error("No se pudo descargar el MP4.");
		triggerDownload(await res.blob(), `${base}.mp4`);
		return;
	}
	const audioSrc = track.media.audioUrl ?? track.media.videoUrl;
	if (!audioSrc) throw new Error("No hay audio público para esta pista.");
	if (format === "mp3") {
		onProgress("Descargando audio original…");
		const filename = `${base}.m4a`;
		const res = await fetch(mediaProxyUrl(audioSrc, filename, true));
		if (!res.ok) throw new Error("No se pudo descargar el audio.");
		triggerDownload(await res.blob(), `${base}.${audioSrc.includes(".mp3") ? "mp3" : "m4a"}`);
		return;
	}
	onProgress("Descargando y convirtiendo a WAV…");
	const res = await fetch(mediaProxyUrl(audioSrc));
	if (!res.ok) throw new Error("No se pudo leer el audio para WAV.");
	const buf = await res.arrayBuffer();
	onProgress("Decodificando…");
	triggerDownload(encodeWav(await decodeAudio(buf)), `${base}.wav`);
}
function DownloaderWidget({ tool, defaultFormat = "mp3" }) {
	const [url, setUrl] = (0, import_react.useState)("");
	const [format, setFormat] = (0, import_react.useState)(defaultFormat);
	const [state, setState] = (0, import_react.useState)({ status: "idle" });
	const [busy, setBusy] = (0, import_react.useState)(null);
	const [selected, setSelected] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const readyTrack = state.status === "song" ? state.track : null;
	const playlist = state.status === "playlist" ? state.playlist : null;
	const selectedTracks = (0, import_react.useMemo)(() => {
		if (!playlist) return [];
		return playlist.tracks.filter((t) => selected.has(t.id));
	}, [playlist, selected]);
	async function resolve(value) {
		const trimmed = value.trim();
		if (trimmed.length < 8) {
			setState({
				status: "error",
				message: "Pega un enlace completo."
			});
			return;
		}
		setState({ status: "loading" });
		try {
			const result = await resolveTrack({ data: { url: trimmed } });
			if (!result.ok) {
				setState({
					status: "error",
					message: result.error
				});
				return;
			}
			if (result.kind === "song") {
				setState({
					status: "song",
					track: result.track
				});
				pushHistory(result.track);
			} else {
				setState({
					status: "playlist",
					playlist: result.playlist
				});
				setSelected(new Set(result.playlist.tracks.map((t) => t.id)));
			}
		} catch (err) {
			const message = err instanceof Error ? err.message : "Error al resolver el enlace.";
			setState({
				status: "error",
				message
			});
		}
	}
	async function onPaste() {
		try {
			const text = await navigator.clipboard.readText();
			if (!text) {
				toast("El portapapeles está vacío");
				return;
			}
			setUrl(text);
			await resolve(text);
		} catch {
			toast("No se pudo leer el portapapeles. Pega el enlace con Ctrl+V.");
		}
	}
	async function onDownloadOne(track) {
		setBusy(track.id);
		try {
			await downloadTrack(track, format, (label) => {
				toast.message(label);
			});
			pushHistory(track);
			toast.success("Descarga lista");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Fallo al descargar");
		} finally {
			setBusy(null);
		}
	}
	async function onDownloadSelected() {
		for (const track of selectedTracks) await onDownloadOne(track);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id: "descargar",
		className: "rounded-2xl bg-card p-3 shadow-[var(--shadow-border)] sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-stretch",
				onSubmit: (e) => {
					e.preventDefault();
					resolve(url);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: url,
					onChange: (e) => setUrl(e.target.value),
					placeholder: tool.placeholder,
					"aria-label": "URL de la canción",
					className: "h-12 rounded-lg sm:flex-1",
					autoComplete: "off",
					inputMode: "url"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2 sm:flex sm:w-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "secondary",
						className: "h-12 rounded-lg",
						onClick: () => void onPaste(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardPaste, {}), "Pegar"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						className: "h-12 rounded-lg",
						disabled: state.status === "loading",
						children: [state.status === "loading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {}), "Analizar"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: FORMATS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setFormat(item.id),
					className: cn("rounded-full px-3 py-1.5 text-left text-sm transition-colors", format === item.id ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: item.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-2 text-[11px] opacity-70",
						children: item.hint
					})]
				}, item.id))
			}),
			tool.example ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-xs text-muted-foreground",
				children: [
					"Prueba con un ejemplo:",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-accent underline-offset-2 hover:underline",
						onClick: () => {
							setUrl(tool.example ?? "https://suno.com/song/e319eea5-df94-49a0-82fd-3141d3cfd36b");
							resolve(tool.example ?? "https://suno.com/song/e319eea5-df94-49a0-82fd-3141d3cfd36b");
						},
						children: "cargar canción de demostración"
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5",
				children: [
					state.status === "idle" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-secondary/60 px-4 py-8 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music2, { className: "mx-auto size-6 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm text-muted-foreground",
							children: [
								"Pega un enlace de ",
								tool.hostHint,
								" para ver la portada, escuchar y descargar."
							]
						})]
					}) : null,
					state.status === "loading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-4 rounded-xl bg-secondary/50 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "size-24 shrink-0 rounded-lg" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-5 w-2/3" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-1/3" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-full" })
							]
						})]
					}) : null,
					state.status === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-xl bg-destructive/10 px-4 py-4 text-sm text-destructive-foreground",
						children: state.message
					}) : null,
					readyTrack ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl bg-secondary/40 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-4 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover, {
								src: readyTrack.media.imageUrl,
								title: readyTrack.title,
								className: "aspect-square w-full rounded-lg sm:h-36 sm:w-36"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-2",
										children: [readyTrack.model ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "accent",
											children: readyTrack.model
										}) : null, readyTrack.playCount != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, { children: [formatCount(readyTrack.playCount), " plays"] }) : null]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-2 font-display text-2xl tracking-tight",
										children: readyTrack.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-muted-foreground",
										children: [readyTrack.artist, readyTrack.handle ? ` · @${readyTrack.handle}` : ""]
									}),
									readyTrack.tags ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 line-clamp-2 text-xs text-muted-foreground",
										children: readyTrack.tags
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudioPlayer, { track: readyTrack })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										className: "mt-4 h-12 w-full rounded-lg sm:w-auto sm:px-8",
										disabled: busy === readyTrack.id,
										onClick: () => void onDownloadOne(readyTrack),
										children: [
											busy === readyTrack.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}),
											"Descargar ",
											format.toUpperCase()
										]
									})
								]
							})]
						}), readyTrack.prompt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
							className: "mt-4 max-h-48 overflow-auto whitespace-pre-wrap rounded-lg bg-background/60 p-3 font-sans text-xs leading-relaxed text-muted-foreground",
							children: readyTrack.prompt
						}) : null]
					}) : null,
					playlist ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-secondary/40 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-end justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs uppercase tracking-wider text-muted-foreground",
									children: "Lista"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-2xl tracking-tight",
									children: playlist.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted-foreground",
									children: [
										playlist.tracks.length,
										" pistas · ",
										selectedTracks.length,
										" seleccionadas"
									]
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								disabled: selectedTracks.length === 0 || Boolean(busy),
								onClick: () => void onDownloadSelected(),
								children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Descargar selección"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 divide-y divide-border",
							children: playlist.tracks.map((track) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-3 py-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": selected.has(track.id) ? "Quitar" : "Seleccionar",
										className: cn("flex size-6 items-center justify-center rounded-sm shadow-[var(--shadow-border)]", selected.has(track.id) ? "bg-accent text-accent-foreground" : "bg-background"),
										onClick: () => {
											setSelected((prev) => {
												const next = new Set(prev);
												if (next.has(track.id)) next.delete(track.id);
												else next.add(track.id);
												return next;
											});
										},
										children: selected.has(track.id) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : null
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover, {
										src: track.media.imageUrl,
										title: track.title,
										className: "size-12 rounded-md"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-sm font-medium",
											children: track.title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-xs text-muted-foreground",
											children: track.artist
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs tabular-nums text-muted-foreground",
										children: formatDuration(track.duration)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "icon",
										variant: "ghost",
										"aria-label": `Descargar ${track.title}`,
										disabled: busy === track.id,
										onClick: () => void onDownloadOne(track),
										children: busy === track.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {})
									})
								]
							}, track.id))
						})]
					}) : null
				]
			})
		]
	});
}
var BENEFITS = [
	{
		title: "Gratis, siempre",
		body: "Sin niveles premium, sin anuncios que bloqueen el archivo, sin registro."
	},
	{
		title: "Tres formatos",
		body: "Audio original (M4A/MP3), WAV sin comprimir para edición y MP4 con visualizador."
	},
	{
		title: "Sin cupos",
		body: "No hay límite diario. Descargas las pistas públicas que pegues."
	},
	{
		title: "Listas incluidas",
		body: "Un enlace de playlist muestra las pistas y permite bajarlas en lote."
	},
	{
		title: "Calidad de origen",
		body: "El audio sale del CDN público de Suno, el mismo que usa el reproductor."
	},
	{
		title: "Privacidad",
		body: "No guardamos tus enlaces en el servidor. El historial vive solo en este navegador."
	}
];
var STEPS = [
	{
		n: "01",
		title: "Copia el enlace",
		body: "En Suno, abre la canción y copia la URL de la barra o pulsa Compartir. Sirve suno.com/song/… y suno.com/s/…",
		icon: Link2
	},
	{
		n: "02",
		title: "Pégalo aquí",
		body: "Usa Pegar o Ctrl+V. Detectamos la pista, la portada, la duración y el audio público.",
		icon: Share2
	},
	{
		n: "03",
		title: "Elige formato y descarga",
		body: "MP3/M4A para escuchar, WAV para producir, MP4 para publicar. El archivo se guarda en tu dispositivo.",
		icon: Download
	}
];
var FAQ = [
	{
		q: "¿Cómo descargar música Suno gratis en 2026?",
		a: "Copia el enlace público de la canción en Suno, pégalo arriba, espera a que aparezca la ficha y pulsa Descargar. No hace falta cuenta de SunoDescarga."
	},
	{
		q: "¿Es gratis y seguro?",
		a: "Sí. No pedimos registro ni tarjeta. No almacenamos los archivos ni un historial en nuestros servidores. Descarga solo tus propias creaciones o material que tengas derecho a copiar."
	},
	{
		q: "¿Funciona con Suno 2026 y las canciones nuevas?",
		a: "Sí. Leemos la página pública de la canción y el audio que Suno sirve en abierto (ahora en M4A) más el MP4 del visualizador."
	},
	{
		q: "¿En qué formatos puedo descargar?",
		a: "Audio original (M4A, a veces MP3), WAV PCM 16-bit generado en tu navegador, y MP4 cuando Suno publica el vídeo."
	},
	{
		q: "¿Necesito una cuenta?",
		a: "No. Si la canción es pública, basta el enlace. Las pistas privadas o no listadas no se pueden leer."
	},
	{
		q: "¿En qué dispositivos funciona?",
		a: "Cualquier navegador moderno: Windows, macOS, Linux, iOS y Android. No hay app que instalar."
	},
	{
		q: "¿Hay límite de descargas?",
		a: "No ponemos cupos. El único límite es el de Suno: si retiran el archivo público, dejarán de funcionar los enlaces."
	},
	{
		q: "¿Por qué falla una descarga?",
		a: "Casi siempre el enlace es privado, está mal copiado o Suno ha cambiado el archivo. Prueba de nuevo, usa el enlace /song/ con UUID, y comprueba que la canción se puede abrir sin iniciar sesión."
	}
];
function PageBody({ tool, defaultFormat = "mp3" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative overflow-hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "pointer-events-none absolute inset-0 opacity-40",
				style: { background: "radial-gradient(ellipse 80% 50% at 50% -10%, color-mix(in oklab, var(--color-accent) 18%, transparent), transparent 60%)" }
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto max-w-6xl px-4 pb-16 pt-14 sm:pt-20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.18em] text-accent",
						children: tool.kicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-4 max-w-3xl font-display text-4xl leading-[1.08] tracking-tight sm:text-5xl lg:text-6xl",
						children: tool.headline
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg",
						children: tool.lede
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted-foreground",
						children: tool.accentNote
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloaderWidget, {
							tool,
							defaultFormat
						})
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl gap-10 px-4 py-16 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl tracking-tight",
					children: "Cómo obtener el enlace de Suno"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-muted-foreground",
					children: "Dos caminos, el mismo resultado: una URL que apunta a una canción pública."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "space-y-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-wider text-muted-foreground",
								children: "Método 1"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-1 text-lg font-medium",
								children: "Barra de direcciones"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted-foreground",
								children: "Abre la ficha de la canción. La URL tiene esta forma:"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
								className: "mt-3 block overflow-x-auto rounded-md bg-secondary px-3 py-2 font-mono text-xs text-accent",
								children: "https://suno.com/song/e319eea5-df94-49a0-82fd-3141d3cfd36b"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-wider text-muted-foreground",
								children: "Método 2"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-1 text-lg font-medium",
								children: "Botón Compartir"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted-foreground",
								children: [
									"En la ficha, pulsa Compartir. Suno copia un enlace corto del tipo",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-accent",
										children: "suno.com/s/…"
									}),
									". También vale."
								]
							})
						]
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4 py-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl tracking-tight",
					children: "Tres pasos"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid gap-4 md:grid-cols-3",
					children: STEPS.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl bg-card p-6 shadow-[var(--shadow-border)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs tabular-nums text-muted-foreground",
									children: step.n
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(step.icon, { className: "size-4 text-accent" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-6 text-lg font-medium",
								children: step.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted-foreground",
								children: step.body
							})
						]
					}, step.n))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4 py-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl tracking-tight",
					children: "Lo que incluye"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
					children: BENEFITS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex size-8 items-center justify-center rounded-sm bg-accent/15 text-accent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-4 font-medium",
								children: item.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1.5 text-sm leading-relaxed text-muted-foreground",
								children: item.body
							})
						]
					}, item.title))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4 py-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl tracking-tight",
					children: "SunoDescarga frente a la descarga oficial"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 overflow-x-auto rounded-xl bg-card shadow-[var(--shadow-border)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[640px] text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "border-b border-border text-xs uppercase tracking-wider text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-5 py-3 font-medium",
									children: "Característica"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-5 py-3 font-medium",
									children: "SunoDescarga"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-5 py-3 font-medium",
									children: "App oficial Suno"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-border",
							children: [
								[
									"MP3 / audio",
									"Gratis (M4A original)",
									"Gratis, con cupos"
								],
								[
									"WAV",
									"Gratis, en el navegador",
									"Solo planes de pago"
								],
								[
									"Vídeo MP4",
									"Si Suno lo publica",
									"Según plan"
								],
								[
									"Registro",
									"No",
									"Sí"
								],
								[
									"Listas",
									"Lote",
									"Pista a pista"
								],
								[
									"Uso comercial",
									"Según términos de Suno",
									"Según suscripción"
								]
							].map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-5 py-3 text-muted-foreground",
									children: row[0]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-5 py-3",
									children: row[1]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-5 py-3 text-muted-foreground",
									children: row[2]
								})
							] }, row[0]))
						})]
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4 py-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl tracking-tight",
					children: "Formatos"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 overflow-x-auto rounded-xl bg-card shadow-[var(--shadow-border)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[560px] text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "border-b border-border text-xs uppercase tracking-wider text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-5 py-3 font-medium",
									children: "Formato"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-5 py-3 font-medium",
									children: "Calidad"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-5 py-3 font-medium",
									children: "Tamaño"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-5 py-3 font-medium",
									children: "Mejor para"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
							className: "divide-y divide-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-3",
										children: "MP3 / M4A"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-3",
										children: "La que Suno publica"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-3 text-muted-foreground",
										children: "Pequeño"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-3 text-muted-foreground",
										children: "Escuchar y compartir"
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-3",
										children: "WAV"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-3",
										children: "PCM 16-bit"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-3 text-muted-foreground",
										children: "Grande (~10×)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-3 text-muted-foreground",
										children: "Edición y master"
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-3",
										children: "MP4"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-3",
										children: "Vídeo + audio"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-3 text-muted-foreground",
										children: "Medio"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-3 text-muted-foreground",
										children: "Redes y presentaciones"
									})
								] })
							]
						})]
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-3xl px-4 py-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl tracking-tight",
					children: "Preguntas frecuentes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Accordion, {
					type: "single",
					collapsible: true,
					className: "mt-6",
					children: FAQ.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
						value: `q-${i}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, { children: item.q }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionContent, { children: item.a })]
					}, item.q))
				})]
			})
		})
	] });
}
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		fill: "none",
		"aria-hidden": "true",
		className,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "1",
				y: "1",
				width: "30",
				height: "30",
				rx: "8",
				className: "stroke-accent",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 18.5c1.4-4.2 2.5-7 3.4-7 1.2 0 1.6 5.8 2.8 5.8 1.1 0 1.6-3.6 2.7-3.6 1.2 0 1.8 5.2 3 5.2 1 0 2.4-4.4 4.1-8.4",
				className: "stroke-foreground",
				strokeWidth: "1.6",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "22.5",
				cy: "10.5",
				r: "1.4",
				className: "fill-accent"
			})
		]
	});
}
function ToolLink({ tool, className, children, onClick }) {
	const label = children ?? tool.nav;
	if (tool.slug === "suno") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/",
		className,
		onClick,
		children: label
	});
	if (tool.slug === "suno-video") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/video",
		className,
		onClick,
		children: label
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/herramientas/$slug",
		params: { slug: tool.slug },
		className,
		onClick,
		children: label
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-border",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-10 px-4 py-14 sm:grid-cols-2 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-7" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-lg tracking-tight",
							children: "SunoDescarga"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-md text-sm leading-relaxed text-muted-foreground",
						children: "Herramienta gratuita para guardar canciones públicas de Suno y otros estudios de música IA. Descarga solo lo que hayas creado o tengas derecho a copiar."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
					children: "Herramientas"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: NAV_TOOLS.slice(0, 6).map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolLink, {
						tool,
						className: "text-sm text-foreground/90 hover:text-accent"
					}) }, tool.slug))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
					children: "Nota legal"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-muted-foreground",
					children: "SunoDescarga no está afiliada a Suno, Inc. Las marcas pertenecen a sus titulares. Respeta los términos de Suno: el uso comercial de creaciones del plan gratuito puede estar restringido."
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mx-auto max-w-6xl px-4 py-5 text-xs text-muted-foreground",
				children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" SunoDescarga. Hecho para guardar tus propias obras."
				]
			})
		})]
	});
}
function SiteHeader({ current }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur-md",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-center gap-2.5",
					onClick: () => setOpen(false),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-lg tracking-tight text-foreground",
						children: "SunoDescarga"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-1 lg:flex",
					children: NAV_TOOLS.slice(0, 5).map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolLink, {
						tool,
						className: `rounded-sm px-2.5 py-1.5 text-[13px] transition-colors ${current === tool.slug ? "text-foreground" : "text-muted-foreground hover:text-foreground"}`
					}, tool.slug))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						className: "hidden sm:inline-flex",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#descargar",
							children: "Descargar"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						className: "lg:hidden",
						"aria-label": open ? "Cerrar menú" : "Abrir menú",
						onClick: () => setOpen((v) => !v),
						children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {})
					})]
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-border bg-background lg:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "mx-auto flex max-w-6xl flex-col px-4 py-3",
				children: NAV_TOOLS.map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolLink, {
					tool,
					className: "py-3 text-sm text-foreground",
					onClick: () => setOpen(false)
				}, tool.slug))
			})
		}) : null]
	});
}
function SiteShell({ children, current }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, { current }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { SiteShell as n, PageBody as t };
