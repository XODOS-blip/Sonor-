//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C8NuFUbD.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/video",
			"/api/media",
			"/herramientas/$slug"
		],
		preloads: ["/assets/index-DN2WcwgI.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DN2WcwgI.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BDNdVkSW.js", "/assets/shell-m2jDnWCy.js"]
	},
	"/video": {
		filePath: "/workspace/src/routes/video.tsx",
		children: void 0,
		preloads: ["/assets/video-BxWLnqRz.js", "/assets/shell-m2jDnWCy.js"]
	},
	"/herramientas/$slug": {
		filePath: "/workspace/src/routes/herramientas.$slug.tsx",
		children: void 0,
		preloads: ["/assets/herramientas._slug-BxdmKhKu.js", "/assets/shell-m2jDnWCy.js"]
	}
} });
//#endregion
export { tsrStartManifest };
