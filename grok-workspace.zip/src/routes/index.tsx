import { createFileRoute } from "@tanstack/react-router";
import { PageBody } from "@/components/marketing/page-body";
import { SiteShell } from "@/components/site/shell";
import { toolBySlug } from "@/lib/catalog";

export const Route = createFileRoute("/")({
  component: Home,
  head: () => ({
    meta: [
      {
        title: "Descargar Suno Música 2026 Gratis — SunoDescarga",
      },
      {
        name: "description",
        content:
          "Descarga canciones de Suno en MP3, WAV y MP4. Gratis, sin registro, compatible con Suno 2026.",
      },
    ],
  }),
});

function Home() {
  const tool = toolBySlug("suno")!;
  return (
    <SiteShell current="suno">
      <PageBody tool={tool} />
    </SiteShell>
  );
}
