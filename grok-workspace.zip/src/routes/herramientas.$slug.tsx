import { createFileRoute, notFound } from "@tanstack/react-router";
import { PageBody } from "@/components/marketing/page-body";
import { SiteShell } from "@/components/site/shell";
import { toolBySlug } from "@/lib/catalog";

export const Route = createFileRoute("/herramientas/$slug")({
  component: ToolPage,
  loader: ({ params }) => {
    const tool = toolBySlug(params.slug);
    if (!tool || tool.slug === "suno" || tool.slug === "suno-video") {
      throw notFound();
    }
    return { tool };
  },
  head: ({ loaderData }) => ({
    meta: [{ title: `${loaderData?.tool.title ?? "Herramienta"} — SunoDescarga` }],
  }),
});

function ToolPage() {
  const { tool } = Route.useLoaderData();
  return (
    <SiteShell current={tool.slug}>
      <PageBody tool={tool} />
    </SiteShell>
  );
}
