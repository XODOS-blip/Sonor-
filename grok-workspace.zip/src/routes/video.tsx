import { createFileRoute } from "@tanstack/react-router";
import { PageBody } from "@/components/marketing/page-body";
import { SiteShell } from "@/components/site/shell";
import { toolBySlug } from "@/lib/catalog";

export const Route = createFileRoute("/video")({
  component: VideoPage,
  head: () => ({
    meta: [{ title: "Descargar vídeo Suno MP4 — SunoDescarga" }],
  }),
});

function VideoPage() {
  const tool = toolBySlug("suno-video")!;
  return (
    <SiteShell current="suno-video">
      <PageBody tool={tool} defaultFormat="mp4" />
    </SiteShell>
  );
}
