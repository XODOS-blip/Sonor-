import { createFileRoute } from "@tanstack/react-router";
import { isAllowedMediaUrl } from "@/lib/suno/hosts";
import { sanitizeFilename } from "@/lib/utils";

const UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";

const MAX_BYTES = 45 * 1024 * 1024;
const TIMEOUT_MS = 45_000;

function guessType(url: string, fallback: string | null): string {
  if (fallback && fallback !== "application/octet-stream") return fallback;
  if (url.endsWith(".mp4")) return "video/mp4";
  if (url.endsWith(".mp3")) return "audio/mpeg";
  if (url.endsWith(".m4a")) return "audio/mp4";
  if (url.endsWith(".wav")) return "audio/wav";
  if (url.endsWith(".jpeg") || url.endsWith(".jpg")) return "image/jpeg";
  if (url.endsWith(".png")) return "image/png";
  if (url.endsWith(".webp")) return "image/webp";
  return fallback || "application/octet-stream";
}

export const Route = createFileRoute("/api/media")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const { searchParams } = new URL(request.url);
        const target = searchParams.get("url");
        const download = searchParams.get("dl") === "1";
        const filenameRaw = searchParams.get("filename") || "suno-media";

        if (!target) {
          return new Response("Falta url", { status: 400 });
        }
        let parsed: URL;
        try {
          parsed = new URL(target);
        } catch {
          return new Response("URL inválida", { status: 400 });
        }
        if (!isAllowedMediaUrl(parsed.toString())) {
          return new Response("Host no permitido", { status: 400 });
        }

        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
        try {
          const upstream = await fetch(parsed.toString(), {
            method: "GET",
            redirect: "follow",
            signal: controller.signal,
            headers: {
              "User-Agent": UA,
              Accept: "*/*",
              Referer: "https://suno.com/",
            },
          });
          if (!upstream.ok || !upstream.body) {
            return new Response("No se pudo obtener el archivo", {
              status: upstream.status === 404 ? 404 : 502,
            });
          }
          const len = Number(upstream.headers.get("content-length") || "0");
          if (len > MAX_BYTES) {
            return new Response("Archivo demasiado grande", { status: 413 });
          }

          const type = guessType(
            parsed.pathname.toLowerCase(),
            upstream.headers.get("content-type"),
          );
          const filename = sanitizeFilename(filenameRaw);
          const headers = new Headers();
          headers.set("Content-Type", type);
          headers.set("Cache-Control", "public, max-age=3600");
          if (download) {
            headers.set("Content-Disposition", `attachment; filename="${filename}"`);
          } else {
            headers.set("Content-Disposition", `inline; filename="${filename}"`);
          }
          const cl = upstream.headers.get("content-length");
          if (cl) headers.set("Content-Length", cl);

          return new Response(upstream.body, { status: 200, headers });
        } catch {
          return new Response("Tiempo de espera agotado", { status: 504 });
        } finally {
          clearTimeout(timer);
        }
      },
    },
  },
});
