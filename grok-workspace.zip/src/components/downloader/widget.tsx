import {
  Check,
  ClipboardPaste,
  Download,
  LoaderCircle,
  Music2,
  Pause,
  Play,
  Sparkles,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { decodeAudio, encodeWav, mediaProxyUrl, triggerDownload } from "@/lib/audio/encode";
import type { ToolDef } from "@/lib/catalog";
import { resolveTrack } from "@/lib/suno/functions";
import { pushHistory } from "@/lib/suno/history";
import { EXAMPLE_SONG_URL } from "@/lib/suno/parse";
import type { MediaFormat, PlaylistInfo, TrackInfo } from "@/lib/suno/types";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { cn, formatCount, formatDuration, sanitizeFilename } from "@/lib/utils";

const FORMATS: { id: MediaFormat; label: string; hint: string }[] = [
  { id: "mp3", label: "MP3 / M4A", hint: "Audio original" },
  { id: "wav", label: "WAV", hint: "Sin pérdidas" },
  { id: "mp4", label: "MP4", hint: "Vídeo + audio" },
];

type ReadyState =
  | { status: "idle" }
  | { status: "loading" }
  | { status: "song"; track: TrackInfo }
  | { status: "playlist"; playlist: PlaylistInfo }
  | { status: "error"; message: string };

function Cover({
  src,
  title,
  className,
}: {
  src: string | null;
  title: string;
  className?: string;
}) {
  const url = src ? mediaProxyUrl(src) : null;
  if (!url) {
    return (
      <div
        className={cn(
          "flex items-center justify-center bg-secondary text-muted-foreground",
          className,
        )}
      >
        <Music2 className="size-8" />
      </div>
    );
  }
  return (
    <img
      src={url}
      alt={`Portada de ${title}`}
      className={cn("object-cover", className)}
      crossOrigin="anonymous"
    />
  );
}

function AudioPlayer({ track }: { track: TrackInfo }) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const src = track.media.audioUrl
    ? mediaProxyUrl(track.media.audioUrl)
    : track.media.videoUrl
      ? mediaProxyUrl(track.media.videoUrl)
      : null;

  useEffect(() => {
    setPlaying(false);
    setProgress(0);
  }, [track.id]);

  if (!src) return null;

  return (
    <div className="flex items-center gap-3">
      <audio
        ref={audioRef}
        src={src}
        preload="metadata"
        onTimeUpdate={(e) => {
          const el = e.currentTarget;
          setProgress(el.duration ? el.currentTime / el.duration : 0);
        }}
        onEnded={() => setPlaying(false)}
      />
      <Button
        type="button"
        size="icon"
        variant="secondary"
        className="size-11 shrink-0 rounded-full"
        aria-label={playing ? "Pausar" : "Reproducir"}
        onClick={() => {
          const el = audioRef.current;
          if (!el) return;
          if (el.paused) {
            void el.play();
            setPlaying(true);
          } else {
            el.pause();
            setPlaying(false);
          }
        }}
      >
        {playing ? <Pause className="size-4" /> : <Play className="ml-0.5 size-4" />}
      </Button>
      <div className="h-1 flex-1 overflow-hidden rounded-full bg-secondary">
        <div
          className="h-full bg-accent transition-[width] duration-150"
          style={{ width: `${Math.round(progress * 100)}%` }}
        />
      </div>
      <span className="w-10 text-right font-mono text-xs tabular-nums text-muted-foreground">
        {formatDuration(track.duration)}
      </span>
    </div>
  );
}

async function downloadTrack(
  track: TrackInfo,
  format: MediaFormat,
  onProgress: (label: string) => void,
) {
  const base = sanitizeFilename(`${track.artist} - ${track.title}`);

  if (format === "mp4") {
    const src = track.media.videoUrl;
    if (!src) throw new Error("Esta pista no tiene vídeo MP4 público.");
    onProgress("Descargando vídeo…");
    const res = await fetch(mediaProxyUrl(src, `${base}.mp4`, true));
    if (!res.ok) throw new Error("No se pudo descargar el MP4.");
    const blob = await res.blob();
    triggerDownload(blob, `${base}.mp4`);
    return;
  }

  const audioSrc = track.media.audioUrl ?? track.media.videoUrl;
  if (!audioSrc) throw new Error("No hay audio público para esta pista.");

  if (format === "mp3") {
    onProgress("Descargando audio original…");
    const filename = `${base}.m4a`;
    const res = await fetch(mediaProxyUrl(audioSrc, filename, true));
    if (!res.ok) throw new Error("No se pudo descargar el audio.");
    const blob = await res.blob();
    const ext = audioSrc.includes(".mp3") ? "mp3" : "m4a";
    triggerDownload(blob, `${base}.${ext}`);
    return;
  }

  onProgress("Descargando y convirtiendo a WAV…");
  const res = await fetch(mediaProxyUrl(audioSrc));
  if (!res.ok) throw new Error("No se pudo leer el audio para WAV.");
  const buf = await res.arrayBuffer();
  onProgress("Decodificando…");
  const audio = await decodeAudio(buf);
  const wav = encodeWav(audio);
  triggerDownload(wav, `${base}.wav`);
}

export function DownloaderWidget({
  tool,
  defaultFormat = "mp3",
}: {
  tool: ToolDef;
  defaultFormat?: MediaFormat;
}) {
  const [url, setUrl] = useState("");
  const [format, setFormat] = useState<MediaFormat>(defaultFormat);
  const [state, setState] = useState<ReadyState>({ status: "idle" });
  const [busy, setBusy] = useState<string | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const readyTrack = state.status === "song" ? state.track : null;
  const playlist = state.status === "playlist" ? state.playlist : null;

  const selectedTracks = useMemo(() => {
    if (!playlist) return [];
    return playlist.tracks.filter((t) => selected.has(t.id));
  }, [playlist, selected]);

  async function resolve(value: string) {
    const trimmed = value.trim();
    if (trimmed.length < 8) {
      setState({ status: "error", message: "Pega un enlace completo." });
      return;
    }
    setState({ status: "loading" });
    try {
      const result = await resolveTrack({ data: { url: trimmed } });
      if (!result.ok) {
        setState({ status: "error", message: result.error });
        return;
      }
      if (result.kind === "song") {
        setState({ status: "song", track: result.track });
        pushHistory(result.track);
      } else {
        setState({ status: "playlist", playlist: result.playlist });
        setSelected(new Set(result.playlist.tracks.map((t) => t.id)));
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "Error al resolver el enlace.";
      setState({ status: "error", message });
    }
  }

  async function onPaste() {
    try {
      const text = await navigator.clipboard.readText();
      if (!text) {
        toast("El portapapeles está vacío");
        return;
      }
      setUrl(text);
      await resolve(text);
    } catch {
      toast("No se pudo leer el portapapeles. Pega el enlace con Ctrl+V.");
    }
  }

  async function onDownloadOne(track: TrackInfo) {
    setBusy(track.id);
    try {
      await downloadTrack(track, format, (label) => {
        toast.message(label);
      });
      pushHistory(track);
      toast.success("Descarga lista");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Fallo al descargar");
    } finally {
      setBusy(null);
    }
  }

  async function onDownloadSelected() {
    for (const track of selectedTracks) {
      await onDownloadOne(track);
    }
  }

  return (
    <div id="descargar" className="rounded-2xl bg-card p-3 shadow-[var(--shadow-border)] sm:p-5">
      <form
        className="flex flex-col gap-3 sm:flex-row sm:items-stretch"
        onSubmit={(e) => {
          e.preventDefault();
          void resolve(url);
        }}
      >
        <Input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder={tool.placeholder}
          aria-label="URL de la canción"
          className="h-12 rounded-lg sm:flex-1"
          autoComplete="off"
          inputMode="url"
        />
        <div className="grid grid-cols-2 gap-2 sm:flex sm:w-auto">
          <Button type="button" variant="secondary" className="h-12 rounded-lg" onClick={() => void onPaste()}>
            <ClipboardPaste />
            Pegar
          </Button>
          <Button type="submit" className="h-12 rounded-lg" disabled={state.status === "loading"}>
            {state.status === "loading" ? (
              <LoaderCircle className="animate-spin" />
            ) : (
              <Sparkles />
            )}
            Analizar
          </Button>
        </div>
      </form>

      <div className="mt-4 flex flex-wrap gap-2">
        {FORMATS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setFormat(item.id)}
            className={cn(
              "rounded-full px-3 py-1.5 text-left text-sm transition-colors",
              format === item.id
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-muted-foreground hover:text-foreground",
            )}
          >
            <span className="font-medium">{item.label}</span>
            <span className="ml-2 text-[11px] opacity-70">{item.hint}</span>
          </button>
        ))}
      </div>

      {tool.example ? (
        <p className="mt-3 text-xs text-muted-foreground">
          Prueba con un ejemplo:{" "}
          <button
            type="button"
            className="text-accent underline-offset-2 hover:underline"
            onClick={() => {
              setUrl(tool.example ?? EXAMPLE_SONG_URL);
              void resolve(tool.example ?? EXAMPLE_SONG_URL);
            }}
          >
            cargar canción de demostración
          </button>
        </p>
      ) : null}

      <div className="mt-5">
        {state.status === "idle" ? (
          <div className="rounded-xl bg-secondary/60 px-4 py-8 text-center">
            <Music2 className="mx-auto size-6 text-muted-foreground" />
            <p className="mt-3 text-sm text-muted-foreground">
              Pega un enlace de {tool.hostHint} para ver la portada, escuchar y descargar.
            </p>
          </div>
        ) : null}

        {state.status === "loading" ? (
          <div className="flex gap-4 rounded-xl bg-secondary/50 p-4">
            <Skeleton className="size-24 shrink-0 rounded-lg" />
            <div className="flex-1 space-y-3">
              <Skeleton className="h-5 w-2/3" />
              <Skeleton className="h-4 w-1/3" />
              <Skeleton className="h-8 w-full" />
            </div>
          </div>
        ) : null}

        {state.status === "error" ? (
          <div className="rounded-xl bg-destructive/10 px-4 py-4 text-sm text-destructive-foreground">
            {state.message}
          </div>
        ) : null}

        {readyTrack ? (
          <article className="rounded-xl bg-secondary/40 p-4">
            <div className="flex flex-col gap-4 sm:flex-row">
              <Cover
                src={readyTrack.media.imageUrl}
                title={readyTrack.title}
                className="aspect-square w-full rounded-lg sm:h-36 sm:w-36"
              />
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  {readyTrack.model ? <Badge variant="accent">{readyTrack.model}</Badge> : null}
                  {readyTrack.playCount != null ? (
                    <Badge>{formatCount(readyTrack.playCount)} plays</Badge>
                  ) : null}
                </div>
                <h3 className="mt-2 font-display text-2xl tracking-tight">{readyTrack.title}</h3>
                <p className="text-sm text-muted-foreground">
                  {readyTrack.artist}
                  {readyTrack.handle ? ` · @${readyTrack.handle}` : ""}
                </p>
                {readyTrack.tags ? (
                  <p className="mt-2 line-clamp-2 text-xs text-muted-foreground">{readyTrack.tags}</p>
                ) : null}
                <div className="mt-4">
                  <AudioPlayer track={readyTrack} />
                </div>
                <Button
                  className="mt-4 h-12 w-full rounded-lg sm:w-auto sm:px-8"
                  disabled={busy === readyTrack.id}
                  onClick={() => void onDownloadOne(readyTrack)}
                >
                  {busy === readyTrack.id ? (
                    <LoaderCircle className="animate-spin" />
                  ) : (
                    <Download />
                  )}
                  Descargar {format.toUpperCase()}
                </Button>
              </div>
            </div>
            {readyTrack.prompt ? (
              <pre className="mt-4 max-h-48 overflow-auto whitespace-pre-wrap rounded-lg bg-background/60 p-3 font-sans text-xs leading-relaxed text-muted-foreground">
                {readyTrack.prompt}
              </pre>
            ) : null}
          </article>
        ) : null}

        {playlist ? (
          <div className="rounded-xl bg-secondary/40 p-4">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <p className="text-xs uppercase tracking-wider text-muted-foreground">Lista</p>
                <h3 className="font-display text-2xl tracking-tight">{playlist.title}</h3>
                <p className="text-sm text-muted-foreground">
                  {playlist.tracks.length} pistas · {selectedTracks.length} seleccionadas
                </p>
              </div>
              <Button
                disabled={selectedTracks.length === 0 || Boolean(busy)}
                onClick={() => void onDownloadSelected()}
              >
                {busy ? <LoaderCircle className="animate-spin" /> : <Download />}
                Descargar selección
              </Button>
            </div>
            <ul className="mt-4 divide-y divide-border">
              {playlist.tracks.map((track) => (
                <li key={track.id} className="flex items-center gap-3 py-3">
                  <button
                    type="button"
                    aria-label={selected.has(track.id) ? "Quitar" : "Seleccionar"}
                    className={cn(
                      "flex size-6 items-center justify-center rounded-sm shadow-[var(--shadow-border)]",
                      selected.has(track.id) ? "bg-accent text-accent-foreground" : "bg-background",
                    )}
                    onClick={() => {
                      setSelected((prev) => {
                        const next = new Set(prev);
                        if (next.has(track.id)) next.delete(track.id);
                        else next.add(track.id);
                        return next;
                      });
                    }}
                  >
                    {selected.has(track.id) ? <Check className="size-3.5" /> : null}
                  </button>
                  <Cover
                    src={track.media.imageUrl}
                    title={track.title}
                    className="size-12 rounded-md"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{track.title}</p>
                    <p className="truncate text-xs text-muted-foreground">{track.artist}</p>
                  </div>
                  <span className="font-mono text-xs tabular-nums text-muted-foreground">
                    {formatDuration(track.duration)}
                  </span>
                  <Button
                    size="icon"
                    variant="ghost"
                    aria-label={`Descargar ${track.title}`}
                    disabled={busy === track.id}
                    onClick={() => void onDownloadOne(track)}
                  >
                    {busy === track.id ? (
                      <LoaderCircle className="animate-spin" />
                    ) : (
                      <Download />
                    )}
                  </Button>
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </div>
    </div>
  );
}
