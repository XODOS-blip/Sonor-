import { NAV_TOOLS } from "@/lib/catalog";
import { Mark } from "./mark";
import { ToolLink } from "./tool-link";

export function SiteFooter() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-14 sm:grid-cols-2 lg:grid-cols-4">
        <div className="lg:col-span-2">
          <div className="flex items-center gap-2.5">
            <Mark className="size-7" />
            <span className="font-display text-lg tracking-tight">SunoDescarga</span>
          </div>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-muted-foreground">
            Herramienta gratuita para guardar canciones públicas de Suno y otros
            estudios de música IA. Descarga solo lo que hayas creado o tengas
            derecho a copiar.
          </p>
        </div>
        <div>
          <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
            Herramientas
          </p>
          <ul className="mt-3 space-y-2">
            {NAV_TOOLS.slice(0, 6).map((tool) => (
              <li key={tool.slug}>
                <ToolLink
                  tool={tool}
                  className="text-sm text-foreground/90 hover:text-accent"
                />
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
            Nota legal
          </p>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
            SunoDescarga no está afiliada a Suno, Inc. Las marcas pertenecen a
            sus titulares. Respeta los términos de Suno: el uso comercial de
            creaciones del plan gratuito puede estar restringido.
          </p>
        </div>
      </div>
      <div className="border-t border-border">
        <p className="mx-auto max-w-6xl px-4 py-5 text-xs text-muted-foreground">
          © {new Date().getFullYear()} SunoDescarga. Hecho para guardar tus propias obras.
        </p>
      </div>
    </footer>
  );
}
