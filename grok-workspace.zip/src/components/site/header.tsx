import { Link } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import { NAV_TOOLS } from "@/lib/catalog";
import { Button } from "@/components/ui/button";
import { Mark } from "./mark";
import { ToolLink } from "./tool-link";

export function SiteHeader({ current }: { current?: string }) {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4">
        <Link to="/" className="flex items-center gap-2.5" onClick={() => setOpen(false)}>
          <Mark className="size-8" />
          <span className="font-display text-lg tracking-tight text-foreground">
            SunoDescarga
          </span>
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {NAV_TOOLS.slice(0, 5).map((tool) => (
            <ToolLink
              key={tool.slug}
              tool={tool}
              className={`rounded-sm px-2.5 py-1.5 text-[13px] transition-colors ${
                current === tool.slug
                  ? "text-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            />
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Button asChild size="sm" className="hidden sm:inline-flex">
            <a href="#descargar">Descargar</a>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            aria-label={open ? "Cerrar menú" : "Abrir menú"}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X /> : <Menu />}
          </Button>
        </div>
      </div>

      {open ? (
        <div className="border-t border-border bg-background lg:hidden">
          <nav className="mx-auto flex max-w-6xl flex-col px-4 py-3">
            {NAV_TOOLS.map((tool) => (
              <ToolLink
                key={tool.slug}
                tool={tool}
                className="py-3 text-sm text-foreground"
                onClick={() => setOpen(false)}
              />
            ))}
          </nav>
        </div>
      ) : null}
    </header>
  );
}
