import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import type { ToolDef } from "@/lib/catalog";

export function ToolLink({
  tool,
  className,
  children,
  onClick,
}: {
  tool: ToolDef;
  className?: string;
  children?: ReactNode;
  onClick?: () => void;
}) {
  const label = children ?? tool.nav;
  if (tool.slug === "suno") {
    return (
      <Link to="/" className={className} onClick={onClick}>
        {label}
      </Link>
    );
  }
  if (tool.slug === "suno-video") {
    return (
      <Link to="/video" className={className} onClick={onClick}>
        {label}
      </Link>
    );
  }
  return (
    <Link
      to="/herramientas/$slug"
      params={{ slug: tool.slug }}
      className={className}
      onClick={onClick}
    >
      {label}
    </Link>
  );
}
