export function Mark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      fill="none"
      aria-hidden="true"
      className={className}
    >
      <rect x="1" y="1" width="30" height="30" rx="8" className="stroke-accent" strokeWidth="1.4" />
      <path
        d="M8 18.5c1.4-4.2 2.5-7 3.4-7 1.2 0 1.6 5.8 2.8 5.8 1.1 0 1.6-3.6 2.7-3.6 1.2 0 1.8 5.2 3 5.2 1 0 2.4-4.4 4.1-8.4"
        className="stroke-foreground"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
      <circle cx="22.5" cy="10.5" r="1.4" className="fill-accent" />
    </svg>
  );
}
