import { Check, Link2, Download, Share2 } from "lucide-react";
import type { ToolDef } from "@/lib/catalog";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { DownloaderWidget } from "@/components/downloader/widget";
import type { MediaFormat } from "@/lib/suno/types";

const BENEFITS = [
  { title: "Gratis, siempre", body: "Sin niveles premium, sin anuncios que bloqueen el archivo, sin registro." },
  { title: "Tres formatos", body: "Audio original (M4A/MP3), WAV sin comprimir para edición y MP4 con visualizador." },
  { title: "Sin cupos", body: "No hay límite diario. Descargas las pistas públicas que pegues." },
  { title: "Listas incluidas", body: "Un enlace de playlist muestra las pistas y permite bajarlas en lote." },
  { title: "Calidad de origen", body: "El audio sale del CDN público de Suno, el mismo que usa el reproductor." },
  { title: "Privacidad", body: "No guardamos tus enlaces en el servidor. El historial vive solo en este navegador." },
];

const STEPS = [
  {
    n: "01",
    title: "Copia el enlace",
    body: "En Suno, abre la canción y copia la URL de la barra o pulsa Compartir. Sirve suno.com/song/… y suno.com/s/…",
    icon: Link2,
  },
  {
    n: "02",
    title: "Pégalo aquí",
    body: "Usa Pegar o Ctrl+V. Detectamos la pista, la portada, la duración y el audio público.",
    icon: Share2,
  },
  {
    n: "03",
    title: "Elige formato y descarga",
    body: "MP3/M4A para escuchar, WAV para producir, MP4 para publicar. El archivo se guarda en tu dispositivo.",
    icon: Download,
  },
];

const FAQ = [
  {
    q: "¿Cómo descargar música Suno gratis en 2026?",
    a: "Copia el enlace público de la canción en Suno, pégalo arriba, espera a que aparezca la ficha y pulsa Descargar. No hace falta cuenta de SunoDescarga.",
  },
  {
    q: "¿Es gratis y seguro?",
    a: "Sí. No pedimos registro ni tarjeta. No almacenamos los archivos ni un historial en nuestros servidores. Descarga solo tus propias creaciones o material que tengas derecho a copiar.",
  },
  {
    q: "¿Funciona con Suno 2026 y las canciones nuevas?",
    a: "Sí. Leemos la página pública de la canción y el audio que Suno sirve en abierto (ahora en M4A) más el MP4 del visualizador.",
  },
  {
    q: "¿En qué formatos puedo descargar?",
    a: "Audio original (M4A, a veces MP3), WAV PCM 16-bit generado en tu navegador, y MP4 cuando Suno publica el vídeo.",
  },
  {
    q: "¿Necesito una cuenta?",
    a: "No. Si la canción es pública, basta el enlace. Las pistas privadas o no listadas no se pueden leer.",
  },
  {
    q: "¿En qué dispositivos funciona?",
    a: "Cualquier navegador moderno: Windows, macOS, Linux, iOS y Android. No hay app que instalar.",
  },
  {
    q: "¿Hay límite de descargas?",
    a: "No ponemos cupos. El único límite es el de Suno: si retiran el archivo público, dejarán de funcionar los enlaces.",
  },
  {
    q: "¿Por qué falla una descarga?",
    a: "Casi siempre el enlace es privado, está mal copiado o Suno ha cambiado el archivo. Prueba de nuevo, usa el enlace /song/ con UUID, y comprueba que la canción se puede abrir sin iniciar sesión.",
  },
];

export function PageBody({
  tool,
  defaultFormat = "mp3",
}: {
  tool: ToolDef;
  defaultFormat?: MediaFormat;
}) {
  return (
    <main>
      <section className="relative overflow-hidden">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 opacity-40"
          style={{
            background:
              "radial-gradient(ellipse 80% 50% at 50% -10%, color-mix(in oklab, var(--color-accent) 18%, transparent), transparent 60%)",
          }}
        />
        <div className="relative mx-auto max-w-6xl px-4 pb-16 pt-14 sm:pt-20">
          <p className="text-xs font-medium uppercase tracking-[0.18em] text-accent">{tool.kicker}</p>
          <h1 className="mt-4 max-w-3xl font-display text-4xl leading-[1.08] tracking-tight sm:text-5xl lg:text-6xl">
            {tool.headline}
          </h1>
          <p className="mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            {tool.lede}
          </p>
          <p className="mt-3 text-sm text-muted-foreground">{tool.accentNote}</p>
          <div className="mt-10">
            <DownloaderWidget tool={tool} defaultFormat={defaultFormat} />
          </div>
        </div>
      </section>

      <section className="border-t border-border">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 lg:grid-cols-2">
          <div>
            <h2 className="font-display text-3xl tracking-tight">Cómo obtener el enlace de Suno</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              Dos caminos, el mismo resultado: una URL que apunta a una canción pública.
            </p>
          </div>
          <ol className="space-y-6">
            <li className="rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
              <p className="text-xs uppercase tracking-wider text-muted-foreground">Método 1</p>
              <h3 className="mt-1 text-lg font-medium">Barra de direcciones</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                Abre la ficha de la canción. La URL tiene esta forma:
              </p>
              <code className="mt-3 block overflow-x-auto rounded-md bg-secondary px-3 py-2 font-mono text-xs text-accent">
                https://suno.com/song/e319eea5-df94-49a0-82fd-3141d3cfd36b
              </code>
            </li>
            <li className="rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
              <p className="text-xs uppercase tracking-wider text-muted-foreground">Método 2</p>
              <h3 className="mt-1 text-lg font-medium">Botón Compartir</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                En la ficha, pulsa Compartir. Suno copia un enlace corto del tipo{" "}
                <span className="font-mono text-accent">suno.com/s/…</span>. También vale.
              </p>
            </li>
          </ol>
        </div>
      </section>

      <section className="border-t border-border">
        <div className="mx-auto max-w-6xl px-4 py-16">
          <h2 className="font-display text-3xl tracking-tight">Tres pasos</h2>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {STEPS.map((step) => (
              <article key={step.n} className="rounded-xl bg-card p-6 shadow-[var(--shadow-border)]">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs tabular-nums text-muted-foreground">{step.n}</span>
                  <step.icon className="size-4 text-accent" />
                </div>
                <h3 className="mt-6 text-lg font-medium">{step.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="border-t border-border">
        <div className="mx-auto max-w-6xl px-4 py-16">
          <h2 className="font-display text-3xl tracking-tight">Lo que incluye</h2>
          <ul className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {BENEFITS.map((item) => (
              <li key={item.title} className="rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
                <div className="flex size-8 items-center justify-center rounded-sm bg-accent/15 text-accent">
                  <Check className="size-4" />
                </div>
                <h3 className="mt-4 font-medium">{item.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{item.body}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="border-t border-border">
        <div className="mx-auto max-w-6xl px-4 py-16">
          <h2 className="font-display text-3xl tracking-tight">SunoDescarga frente a la descarga oficial</h2>
          <div className="mt-8 overflow-x-auto rounded-xl bg-card shadow-[var(--shadow-border)]">
            <table className="w-full min-w-[640px] text-left text-sm">
              <thead className="border-b border-border text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-5 py-3 font-medium">Característica</th>
                  <th className="px-5 py-3 font-medium">SunoDescarga</th>
                  <th className="px-5 py-3 font-medium">App oficial Suno</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {[
                  ["MP3 / audio", "Gratis (M4A original)", "Gratis, con cupos"],
                  ["WAV", "Gratis, en el navegador", "Solo planes de pago"],
                  ["Vídeo MP4", "Si Suno lo publica", "Según plan"],
                  ["Registro", "No", "Sí"],
                  ["Listas", "Lote", "Pista a pista"],
                  ["Uso comercial", "Según términos de Suno", "Según suscripción"],
                ].map((row) => (
                  <tr key={row[0]}>
                    <td className="px-5 py-3 text-muted-foreground">{row[0]}</td>
                    <td className="px-5 py-3">{row[1]}</td>
                    <td className="px-5 py-3 text-muted-foreground">{row[2]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className="border-t border-border">
        <div className="mx-auto max-w-6xl px-4 py-16">
          <h2 className="font-display text-3xl tracking-tight">Formatos</h2>
          <div className="mt-8 overflow-x-auto rounded-xl bg-card shadow-[var(--shadow-border)]">
            <table className="w-full min-w-[560px] text-left text-sm">
              <thead className="border-b border-border text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-5 py-3 font-medium">Formato</th>
                  <th className="px-5 py-3 font-medium">Calidad</th>
                  <th className="px-5 py-3 font-medium">Tamaño</th>
                  <th className="px-5 py-3 font-medium">Mejor para</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                <tr>
                  <td className="px-5 py-3">MP3 / M4A</td>
                  <td className="px-5 py-3">La que Suno publica</td>
                  <td className="px-5 py-3 text-muted-foreground">Pequeño</td>
                  <td className="px-5 py-3 text-muted-foreground">Escuchar y compartir</td>
                </tr>
                <tr>
                  <td className="px-5 py-3">WAV</td>
                  <td className="px-5 py-3">PCM 16-bit</td>
                  <td className="px-5 py-3 text-muted-foreground">Grande (~10×)</td>
                  <td className="px-5 py-3 text-muted-foreground">Edición y master</td>
                </tr>
                <tr>
                  <td className="px-5 py-3">MP4</td>
                  <td className="px-5 py-3">Vídeo + audio</td>
                  <td className="px-5 py-3 text-muted-foreground">Medio</td>
                  <td className="px-5 py-3 text-muted-foreground">Redes y presentaciones</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className="border-t border-border">
        <div className="mx-auto max-w-3xl px-4 py-16">
          <h2 className="font-display text-3xl tracking-tight">Preguntas frecuentes</h2>
          <Accordion type="single" collapsible className="mt-6">
            {FAQ.map((item, i) => (
              <AccordionItem key={item.q} value={`q-${i}`}>
                <AccordionTrigger>{item.q}</AccordionTrigger>
                <AccordionContent>{item.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>
    </main>
  );
}
