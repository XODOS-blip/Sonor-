function floatTo16(input: Float32Array): Int16Array {
  const out = new Int16Array(input.length);
  for (let i = 0; i < input.length; i++) {
    const s = Math.max(-1, Math.min(1, input[i] ?? 0));
    out[i] = s < 0 ? Math.round(s * 0x8000) : Math.round(s * 0x7fff);
  }
  return out;
}

function interleave(buffer: AudioBuffer): Int16Array {
  const ch = buffer.numberOfChannels;
  const len = buffer.length;
  if (ch === 1) return floatTo16(buffer.getChannelData(0));
  const left = buffer.getChannelData(0);
  const right = buffer.getChannelData(1);
  const out = new Int16Array(len * 2);
  for (let i = 0; i < len; i++) {
    const l = Math.max(-1, Math.min(1, left[i] ?? 0));
    const r = Math.max(-1, Math.min(1, right[i] ?? 0));
    out[i * 2] = l < 0 ? Math.round(l * 0x8000) : Math.round(l * 0x7fff);
    out[i * 2 + 1] = r < 0 ? Math.round(r * 0x8000) : Math.round(r * 0x7fff);
  }
  return out;
}

export function encodeWav(buffer: AudioBuffer): Blob {
  const channels = Math.min(2, buffer.numberOfChannels) as 1 | 2;
  const samples = interleave(buffer);
  const bytesPerSample = 2;
  const blockAlign = channels * bytesPerSample;
  const dataSize = samples.length * bytesPerSample;
  const header = 44;
  const ab = new ArrayBuffer(header + dataSize);
  const view = new DataView(ab);

  const writeStr = (offset: number, s: string) => {
    for (let i = 0; i < s.length; i++) view.setUint8(offset + i, s.charCodeAt(i));
  };

  writeStr(0, "RIFF");
  view.setUint32(4, 36 + dataSize, true);
  writeStr(8, "WAVE");
  writeStr(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, channels, true);
  view.setUint32(24, buffer.sampleRate, true);
  view.setUint32(28, buffer.sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, 16, true);
  writeStr(36, "data");
  view.setUint32(40, dataSize, true);
  new Int16Array(ab, header).set(samples);
  return new Blob([ab], { type: "audio/wav" });
}

export async function decodeAudio(data: ArrayBuffer): Promise<AudioBuffer> {
  const ctx = new AudioContext();
  try {
    const copy = data.slice(0);
    return await ctx.decodeAudioData(copy);
  } finally {
    await ctx.close().catch(() => undefined);
  }
}

export function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4_000);
}

export function mediaProxyUrl(src: string, filename?: string, download = false): string {
  const params = new URLSearchParams({ url: src });
  if (filename) params.set("filename", filename);
  if (download) params.set("dl", "1");
  return `/api/media?${params.toString()}`;
}
