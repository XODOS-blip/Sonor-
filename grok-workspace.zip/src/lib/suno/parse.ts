import type { ParsedInput } from "./types";

const UUID =
  "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}";
const UUID_RE = new RegExp(`^${UUID}$`, "i");

export const EXAMPLE_SONG_URL =
  "https://suno.com/song/e319eea5-df94-49a0-82fd-3141d3cfd36b";

export function parseSunoInput(raw: string): ParsedInput | null {
  const trimmed = raw.trim();
  if (!trimmed) return null;

  if (UUID_RE.test(trimmed)) {
    return { kind: "uuid", id: trimmed.toLowerCase() };
  }

  let url: URL;
  try {
    url = new URL(trimmed.includes("://") ? trimmed : `https://${trimmed}`);
  } catch {
    return null;
  }

  const host = url.hostname.replace(/^www\./, "").toLowerCase();

  if (host === "suno.com" || host === "suno.ai") {
    const parts = url.pathname.split("/").filter(Boolean);
    if (parts[0] === "song" && parts[1] && UUID_RE.test(parts[1])) {
      return { kind: "song", id: parts[1].toLowerCase() };
    }
    if (parts[0] === "playlist" && parts[1] && UUID_RE.test(parts[1])) {
      return { kind: "playlist", id: parts[1].toLowerCase() };
    }
    if (parts[0] === "s" && parts[1]) {
      return { kind: "short", id: parts[1] };
    }
    if (parts[0] === "embed" && parts[1] && UUID_RE.test(parts[1])) {
      return { kind: "song", id: parts[1].toLowerCase() };
    }
  }

  if (host.includes("suno") || host.includes("mureka") || host.includes("soundraw") || host.includes("mubert") || host.includes("loudly") || host.includes("openmusic") || host.includes("makebestmusic") || host.includes("aisongmaker") || host.includes("udio")) {
    return { kind: "generic", url: url.toString() };
  }

  return { kind: "generic", url: url.toString() };
}

export function isLikelyUrl(raw: string): boolean {
  const t = raw.trim();
  if (!t) return false;
  if (UUID_RE.test(t)) return true;
  return /suno\.|https?:\/\//i.test(t);
}
