export type MediaFormat = "mp3" | "wav" | "mp4";

export type ResolvedKind = "song" | "playlist";

export type TrackMedia = {
  audioUrl: string | null;
  videoUrl: string | null;
  imageUrl: string | null;
};

export type TrackInfo = {
  id: string;
  title: string;
  artist: string;
  handle: string | null;
  duration: number | null;
  tags: string | null;
  prompt: string | null;
  playCount: number | null;
  upvoteCount: number | null;
  model: string | null;
  createdAt: string | null;
  pageUrl: string;
  media: TrackMedia;
};

export type PlaylistInfo = {
  id: string;
  title: string;
  pageUrl: string;
  tracks: TrackInfo[];
};

export type ResolveOk =
  | { ok: true; kind: "song"; track: TrackInfo }
  | { ok: true; kind: "playlist"; playlist: PlaylistInfo };

export type ResolveErr = { ok: false; error: string };

export type ResolveResult = ResolveOk | ResolveErr;

export type ParsedInput =
  | { kind: "song"; id: string }
  | { kind: "short"; id: string }
  | { kind: "playlist"; id: string }
  | { kind: "uuid"; id: string }
  | { kind: "generic"; url: string };
