import { parseSunoInput } from "./parse";
import { isAllowedMediaUrl, PAGE_HOSTS } from "./hosts";
import type { ResolveResult, TrackInfo } from "./types";

const UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";

const FETCH_TIMEOUT_MS = 18_000;
const MAX_HTML_BYTES = 2_000_000;

const UUID_RE =
  /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;

async function fetchText(url: string, init?: RequestInit): Promise<string> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      ...init,
      redirect: init?.redirect ?? "follow",
      signal: controller.signal,
      headers: {
        "User-Agent": UA,
        Accept: "text/html,application/json;q=0.9,*/*;q=0.8",
        ...(init?.headers ?? {}),
      },
    });
    if (!res.ok) {
      throw new Error(`HTTP ${res.status}`);
    }
    const buf = await res.arrayBuffer();
    if (buf.byteLength > MAX_HTML_BYTES) {
      throw new Error("Respuesta demasiado grande");
    }
    return new TextDecoder("utf-8").decode(buf);
  } finally {
    clearTimeout(timer);
  }
}

function unescapeJs(chunk: string): string {
  return chunk
    .replace(/\\"/g, '"')
    .replace(/\\n/g, "\n")
    .replace(/\\t/g, "\t")
    .replace(/\\\//g, "/")
    .replace(/\\u002F/gi, "/");
}

function pickString(source: string, key: string): string | null {
  const re = new RegExp(`"${key}"\\s*:\\s*"((?:\\\\.|[^"\\\\])*)"`);
  const m = source.match(re);
  if (!m?.[1]) return null;
  try {
    return JSON.parse(`"${m[1]}"`) as string;
  } catch {
    return m[1].replace(/\\n/g, "\n");
  }
}

function pickNumber(source: string, key: string): number | null {
  const re = new RegExp(`"${key}"\\s*:\\s*(-?\\d+(?:\\.\\d+)?)`);
  const m = source.match(re);
  if (!m?.[1]) return null;
  const n = Number(m[1]);
  return Number.isFinite(n) ? n : null;
}

function metaContent(html: string, property: string): string | null {
  const re = new RegExp(
    `<meta[^>]+(?:property|name)=["']${property}["'][^>]+content=["']([^"']+)["']`,
    "i",
  );
  const m = html.match(re);
  if (m?.[1]) return m[1];
  const re2 = new RegExp(
    `<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["']${property}["']`,
    "i",
  );
  return html.match(re2)?.[1] ?? null;
}

function titleTag(html: string): string | null {
  return html.match(/<title[^>]*>([^<]+)<\/title>/i)?.[1]?.trim() ?? null;
}

async function resolveShortId(shortId: string): Promise<string> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  try {
    const res = await fetch(`https://suno.com/s/${encodeURIComponent(shortId)}`, {
      method: "GET",
      redirect: "manual",
      signal: controller.signal,
      headers: { "User-Agent": UA, Accept: "text/html" },
    });
    const location = res.headers.get("location") ?? "";
    const match = location.match(UUID_RE);
    if (match) return match[0].toLowerCase();
    if (res.status >= 300 && res.status < 400 && location) {
      const abs = new URL(location, "https://suno.com").toString();
      const again = abs.match(UUID_RE);
      if (again) return again[0].toLowerCase();
    }
    throw new Error("No se pudo resolver el enlace corto de Suno");
  } finally {
    clearTimeout(timer);
  }
}

function windowAround(html: string, needle: string, before = 6000, after = 14000): string {
  const idx = html.indexOf(needle);
  if (idx < 0) return "";
  return html.slice(Math.max(0, idx - before), idx + after);
}

function buildAudioUrl(id: string, html: string, unescaped: string): string | null {
  const media = unescaped.match(
    /https:\/\/d2lwuy8qc234o3\.cloudfront\.net\/[^"\\\s]+/,
  );
  if (media && isAllowedMediaUrl(media[0])) return media[0];
  const m4a = `https://d2lwuy8qc234o3.cloudfront.net/1/clip/${id}.m4a`;
  const mp3 = `https://cdn1.suno.ai/${id}.mp3`;
  if (html.includes("d2lwuy8qc234o3.cloudfront.net")) return m4a;
  if (html.includes(`${id}.mp3`)) return mp3;
  return m4a;
}

function buildVideoUrl(id: string, html: string, unescaped: string): string | null {
  const fromJson = pickString(unescaped, "video_url");
  if (fromJson && isAllowedMediaUrl(fromJson) && !fromJson.includes("forbidden")) {
    return fromJson;
  }
  const og = metaContent(html, "og:video") ?? metaContent(html, "og:video:secure_url");
  if (og && isAllowedMediaUrl(og)) return og;
  return `https://cdn1.suno.ai/${id}.mp4`;
}

function parseTrackFromHtml(id: string, html: string): TrackInfo {
  const rawWindow =
    windowAround(html, `"id":"${id}"`) ||
    windowAround(html, `song_schema`) ||
    windowAround(html, id);
  const unescaped = unescapeJs(rawWindow || html.slice(0, 250_000));

  const ogTitle = metaContent(html, "og:title");
  const pageTitle = titleTag(html);
  const titleFromJson = pickString(unescaped, "title");
  let title =
    titleFromJson ||
    ogTitle ||
    pageTitle?.replace(/\s+by\s+.+\|\s*Suno.*$/i, "").trim() ||
    "Canción Suno";

  if (title.toLowerCase() === "suno") title = titleFromJson || "Canción Suno";

  const handle = pickString(unescaped, "handle");
  let artist = pickString(unescaped, "display_name") ?? "";
  if (!artist || artist.length <= 4) {
    const userBlock = unescaped.match(
      /"display_name"\s*:\s*"((?:\\.|[^"\\])*)"\s*,\s*"handle"\s*:\s*"((?:\\.|[^"\\])*)"/,
    );
    if (userBlock) {
      try {
        artist = JSON.parse(`"${userBlock[1]}"`) as string;
      } catch {
        artist = userBlock[1];
      }
    }
  }
  if (!artist || /^v\d/i.test(artist)) {
    const by = pageTitle?.match(/\sby\s+(.+?)\s+\|\s*Suno/i)?.[1];
    artist = by?.trim() || handle || "Artista Suno";
  }

  const tags =
    pickString(unescaped, "display_tags") || pickString(unescaped, "tags");
  let prompt = pickString(unescaped, "prompt");
  if (prompt && /^\$\d+$/.test(prompt.trim())) prompt = null;

  const image =
    pickString(unescaped, "image_large_url") ||
    pickString(unescaped, "image_url") ||
    metaContent(html, "og:image");

  const duration =
    pickNumber(unescaped, "duration") ?? pickNumber(unescaped, "duration_sec");

  return {
    id,
    title: title.trim(),
    artist: artist.trim(),
    handle,
    duration,
    tags,
    prompt,
    playCount: pickNumber(unescaped, "play_count"),
    upvoteCount: pickNumber(unescaped, "upvote_count"),
    model:
      pickString(unescaped, "major_model_version") ||
      pickString(unescaped, "model_name"),
    createdAt: pickString(unescaped, "created_at"),
    pageUrl: `https://suno.com/song/${id}`,
    media: {
      audioUrl: buildAudioUrl(id, html, unescaped),
      videoUrl: buildVideoUrl(id, html, unescaped),
      imageUrl: image && isAllowedMediaUrl(image) ? image : null,
    },
  };
}

async function fetchSong(id: string): Promise<TrackInfo> {
  const html = await fetchText(`https://suno.com/song/${id}`);
  const track = parseTrackFromHtml(id, html);

  try {
    const oembed = await fetchText(
      `https://studio-api-prod.suno.com/api/oembed?url=${encodeURIComponent(track.pageUrl)}`,
    );
    const json = JSON.parse(oembed) as { title?: string };
    if (json.title && json.title.length > 1) track.title = json.title;
  } catch {
    /* oembed is optional */
  }

  return track;
}

function extractPlaylistTracks(html: string, playlistId: string): TrackInfo[] {
  const ids = new Set<string>();
  const re = new RegExp(
    `"id"\\s*:\\s*"([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})"`,
    "gi",
  );
  let m: RegExpExecArray | null;
  const unescaped = unescapeJs(html);
  while ((m = re.exec(unescaped))) {
    const id = m[1].toLowerCase();
    if (id !== playlistId) ids.add(id);
  }

  const tracks: TrackInfo[] = [];
  for (const id of ids) {
    if (tracks.length >= 40) break;
    try {
      tracks.push(parseTrackFromHtml(id, html));
    } catch {
      tracks.push({
        id,
        title: "Pista",
        artist: "Suno",
        handle: null,
        duration: null,
        tags: null,
        prompt: null,
        playCount: null,
        upvoteCount: null,
        model: null,
        createdAt: null,
        pageUrl: `https://suno.com/song/${id}`,
        media: {
          audioUrl: `https://d2lwuy8qc234o3.cloudfront.net/1/clip/${id}.m4a`,
          videoUrl: `https://cdn1.suno.ai/${id}.mp4`,
          imageUrl: null,
        },
      });
    }
  }
  return tracks;
}

async function fetchPlaylist(id: string) {
  const html = await fetchText(`https://suno.com/playlist/${id}`);
  const title =
    metaContent(html, "og:title") ||
    titleTag(html)?.replace(/\s+\|\s*Suno.*$/i, "") ||
    "Lista de reproducción";
  const tracks = extractPlaylistTracks(html, id);
  if (tracks.length === 0) {
    throw new Error("No se encontraron canciones en esa lista");
  }
  return {
    id,
    title,
    pageUrl: `https://suno.com/playlist/${id}`,
    tracks,
  };
}

async function resolveGeneric(url: string): Promise<ResolveResult> {
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    return { ok: false, error: "URL no válida." };
  }
  if (parsed.protocol !== "https:") {
    return { ok: false, error: "Solo se aceptan enlaces HTTPS." };
  }
  const host = parsed.hostname.replace(/^www\./, "").toLowerCase();
  if (!PAGE_HOSTS.has(parsed.hostname) && host !== "suno.com" && host !== "suno.ai") {
    return {
      ok: false,
      error:
        "Esta herramienta lee sobre todo enlaces públicos de Suno. Pega una URL de suno.com/song/…",
    };
  }

  const html = await fetchText(parsed.toString());
  const id = html.match(UUID_RE)?.[0];
  if (!id) return { ok: false, error: "No se encontró una canción en esa URL." };
  const track = parseTrackFromHtml(id.toLowerCase(), html);
  return { ok: true, kind: "song", track };
}

export async function resolveSunoUrl(raw: string): Promise<ResolveResult> {
  const parsed = parseSunoInput(raw);
  if (!parsed) {
    return {
      ok: false,
      error: "Pega un enlace de Suno. Ejemplos: suno.com/song/… o suno.com/s/…",
    };
  }

  try {
    if (parsed.kind === "short") {
      const id = await resolveShortId(parsed.id);
      const track = await fetchSong(id);
      return { ok: true, kind: "song", track };
    }
    if (parsed.kind === "song" || parsed.kind === "uuid") {
      const track = await fetchSong(parsed.id);
      return { ok: true, kind: "song", track };
    }
    if (parsed.kind === "playlist") {
      const playlist = await fetchPlaylist(parsed.id);
      return { ok: true, kind: "playlist", playlist };
    }
    return await resolveGeneric(parsed.url);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Error desconocido";
    if (message.includes("abort")) {
      return { ok: false, error: "Suno tardó demasiado en responder. Inténtalo de nuevo." };
    }
    return {
      ok: false,
      error: `No se pudo leer esa canción (${message}). Comprueba que el enlace sea público.`,
    };
  }
}
