import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type { ResolveResult } from "./types";

const Input = z.object({
  url: z.string().min(8).max(2000),
});

export const resolveTrack = createServerFn({ method: "POST" })
  .validator((data: unknown) => Input.parse(data))
  .handler(async ({ data }): Promise<ResolveResult> => {
    const { resolveSunoUrl } = await import("./resolve.server");
    return resolveSunoUrl(data.url);
  });
