import type { TrackInfo } from "./types";

const KEY = "sunodescarga.history.v1";
const MAX = 24;

export type HistoryItem = {
  id: string;
  title: string;
  artist: string;
  imageUrl: string | null;
  pageUrl: string;
  savedAt: number;
};

function read(): HistoryItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as HistoryItem[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function loadHistory(): HistoryItem[] {
  return read();
}

export function pushHistory(track: TrackInfo): HistoryItem[] {
  const next: HistoryItem = {
    id: track.id,
    title: track.title,
    artist: track.artist,
    imageUrl: track.media.imageUrl,
    pageUrl: track.pageUrl,
    savedAt: Date.now(),
  };
  const rest = read().filter((item) => item.id !== track.id);
  const list = [next, ...rest].slice(0, MAX);
  localStorage.setItem(KEY, JSON.stringify(list));
  return list;
}

export function clearHistory() {
  localStorage.removeItem(KEY);
}
