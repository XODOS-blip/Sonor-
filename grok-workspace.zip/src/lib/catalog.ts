export type ToolSlug =
  | "suno"
  | "suno-video"
  | "mureka"
  | "soundraw"
  | "mubert"
  | "loudly"
  | "openmusic"
  | "makebestmusic"
  | "aisongmaker";

export type ToolDef = {
  slug: ToolSlug;
  href: string;
  nav: string;
  title: string;
  kicker: string;
  headline: string;
  lede: string;
  placeholder: string;
  example?: string;
  hostHint: string;
  accentNote: string;
};

export const TOOLS: ToolDef[] = [
  {
    slug: "suno",
    href: "/",
    nav: "Suno Música",
    title: "Descargar música Suno",
    kicker: "Suno 2026 · MP3 / WAV / MP4",
    headline: "Descarga gratuita de música Suno",
    lede: "Pega el enlace de una canción pública de Suno y llévatela en audio original, WAV sin comprimir o vídeo MP4. Sin cuenta, sin cupos diarios.",
    placeholder: "https://suno.com/song/… o https://suno.com/s/…",
    example: "https://suno.com/song/e319eea5-df94-49a0-82fd-3141d3cfd36b",
    hostHint: "suno.com",
    accentNote: "Compatible con canciones y listas públicas de Suno 2026.",
  },
  {
    slug: "suno-video",
    href: "/video",
    nav: "Suno Vídeo",
    title: "Descargar vídeo Suno",
    kicker: "Visualizador MP4",
    headline: "Guarda el vídeo de tus canciones Suno",
    lede: "El visualizador oficial viaja con la pista. Extrae el MP4 listo para redes, o quédate solo con el audio.",
    placeholder: "https://suno.com/song/…",
    example: "https://suno.com/song/e319eea5-df94-49a0-82fd-3141d3cfd36b",
    hostHint: "suno.com",
    accentNote: "El MP4 público de Suno incluye audio y visualizador.",
  },
  {
    slug: "mureka",
    href: "/herramientas/mureka",
    nav: "Mureka",
    title: "Descargar Mureka",
    kicker: "Música Mureka AI",
    headline: "Descargador de música Mureka",
    lede: "Pega un enlace público de Mureka. Si la pista expone audio abierto, la preparamos para descarga.",
    placeholder: "Pega una URL de Mureka",
    hostHint: "mureka.ai",
    accentNote: "Funciona con páginas que publican og:audio o un archivo directo.",
  },
  {
    slug: "soundraw",
    href: "/herramientas/soundraw",
    nav: "SoundRaw",
    title: "Descargar SoundRaw",
    kicker: "SoundRaw",
    headline: "Lleva tus pistas de SoundRaw al disco",
    lede: "Para pistas públicas con archivo de audio enlazado. Ideal cuando ya tienes el enlace de la canción.",
    placeholder: "Pega una URL de SoundRaw",
    hostHint: "soundraw.io",
    accentNote: "Lee metadatos abiertos de la página (título, portada, audio).",
  },
  {
    slug: "mubert",
    href: "/herramientas/mubert",
    nav: "Mubert",
    title: "Descargar Mubert",
    kicker: "Mubert",
    headline: "Exporta streams de Mubert",
    lede: "Si el enlace apunta a una pieza pública, intentamos extraer el archivo y la portada.",
    placeholder: "Pega una URL de Mubert",
    hostHint: "mubert.com",
    accentNote: "No accede a bibliotecas privadas ni cuentas.",
  },
  {
    slug: "loudly",
    href: "/herramientas/loudly",
    nav: "Loudly",
    title: "Descargar Loudly",
    kicker: "Loudly",
    headline: "Descargador Loudly",
    lede: "Pega el enlace público de una pista Loudly para ver si hay un archivo descargable.",
    placeholder: "Pega una URL de Loudly",
    hostHint: "loudly.com",
    accentNote: "Solo contenido publicado de forma abierta.",
  },
  {
    slug: "openmusic",
    href: "/herramientas/openmusic",
    nav: "OpenMusic",
    title: "Descargar OpenMusic",
    kicker: "OpenMusic",
    headline: "OpenMusic, en local",
    lede: "Extrae audio público a partir de la URL de la canción.",
    placeholder: "Pega una URL de OpenMusic",
    hostHint: "openmusic",
    accentNote: "Pensado para páginas con reproductor embebido público.",
  },
  {
    slug: "makebestmusic",
    href: "/herramientas/makebestmusic",
    nav: "MakeBestMusic",
    title: "Descargar MakeBestMusic",
    kicker: "MakeBestMusic",
    headline: "Guarda tus pistas de MakeBestMusic",
    lede: "Un lector de enlaces públicos: título, portada y archivo si está expuesto.",
    placeholder: "Pega una URL de MakeBestMusic",
    hostHint: "makebestmusic",
    accentNote: "Sin registro. Sin almacenamiento de tus enlaces en el servidor.",
  },
  {
    slug: "aisongmaker",
    href: "/herramientas/aisongmaker",
    nav: "AI Song Maker",
    title: "Descargar AI Song Maker",
    kicker: "AI Song Maker",
    headline: "Descarga desde AI Song Maker",
    lede: "Pega la URL pública de una canción generada y la preparamos si hay audio abierto.",
    placeholder: "Pega una URL de AI Song Maker",
    hostHint: "aisongmaker",
    accentNote: "Respeta los términos de cada plataforma.",
  },
];

export function toolBySlug(slug: string): ToolDef | undefined {
  return TOOLS.find((t) => t.slug === slug);
}

export const NAV_TOOLS = TOOLS;
